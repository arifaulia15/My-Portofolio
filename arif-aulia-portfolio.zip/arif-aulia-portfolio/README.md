# Portfolio Arif Aulia

Website portfolio berdasarkan sketsa yang diberikan.

## Struktur folder

```text
arif-aulia-portfolio/
├── index.html
├── style.css
├── script.js
└── assets/
    ├── foto-utama.jpg
    ├── foto-profil.jpg
    ├── project-1.jpg
    ├── project-2.jpg
    └── project-3.jpg
```

## Cara upload ke GitHub

1. Buat repository baru, misalnya `portfolio-arif-aulia`.
2. Upload `index.html`, `style.css`, `script.js`, dan folder `assets`.
3. Masuk ke **Settings → Pages**.
4. Pada **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/ (root)`.
6. Save.
7. Tunggu beberapa saat, lalu GitHub akan memberikan link website.

## Mengganti foto

Masukkan foto ke folder `assets` dengan nama:
- `foto-utama.jpg`
- `foto-profil.jpg`
- `project-1.jpg`
- `project-2.jpg`
- `project-3.jpg`

## Mengganti data

Edit bagian teks di `index.html`, terutama:
- Nama
- Profesi
- Lokasi
- Email
- Instagram
- GitHub
- Nama dan deskripsi project
